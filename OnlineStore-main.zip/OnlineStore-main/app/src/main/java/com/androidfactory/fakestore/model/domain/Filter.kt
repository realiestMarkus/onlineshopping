package com.androidfactory.fakestore.model.domain

data class Filter(
    val value: String = "",
    val displayText: String = ""
)
