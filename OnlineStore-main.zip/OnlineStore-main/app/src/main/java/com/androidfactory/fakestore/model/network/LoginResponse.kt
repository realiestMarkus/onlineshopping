package com.androidfactory.fakestore.model.network

data class LoginResponse(val token: String)
